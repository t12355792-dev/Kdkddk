package com.example.haven;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.PillarBlock;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.item.equipment.EquipmentAssetKeys;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.UnaryOperator;

/** Все блоки и предметы мода. */
public final class ModContent {
    public static final String ID = "havenmod";
    public static final String[] MATS = {"rune", "storm", "hellfire", "celestial", "cosmic"};

    public static final List<Item> TAB = new ArrayList<>();

    public static final Block[] ORE = new Block[5];
    public static final Item[] RAW = new Item[5];
    public static final Item[] INGOT = new Item[5];
    /** [материал][0 шлем, 1 нагрудник, 2 поножи, 3 ботинки] */
    public static final Item[][] ARMOR = new Item[5][4];

    public static Block LEPIDODENDRON_LOG;
    public static Block LEPIDODENDRON_LEAVES;
    public static Item KRATOS_AXE, ZEUS_AXE, HELL_AXE, HEAVEN_AXE, GALAXY_AXE;

    private static Identifier id(String n) { return Identifier.of(ID, n); }

    private static Block block(String name, float hardness, float resistance, BlockSoundGroup sound,
                               boolean requiresTool, Function<AbstractBlock.Settings, Block> factory) {
        RegistryKey<Block> bk = RegistryKey.of(RegistryKeys.BLOCK, id(name));
        RegistryKey<Item> ik = RegistryKey.of(RegistryKeys.ITEM, id(name));
        AbstractBlock.Settings s = AbstractBlock.Settings.create()
                .registryKey(bk).strength(hardness, resistance).sounds(sound);
        if (requiresTool) s = s.requiresTool();
        Block b = factory.apply(s);
        Registry.register(Registries.BLOCK, bk, b);
        BlockItem bi = new BlockItem(b, new Item.Settings().registryKey(ik).useBlockPrefixedTranslationKey());
        Registry.register(Registries.ITEM, ik, bi);
        TAB.add(bi);
        return b;
    }

    private static Item item(String name, Function<Item.Settings, Item> factory, UnaryOperator<Item.Settings> cfg) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id(name));
        Item.Settings s = new Item.Settings().registryKey(key);
        if (cfg != null) s = cfg.apply(s);
        Item it = factory.apply(s);
        Registry.register(Registries.ITEM, key, it);
        TAB.add(it);
        return it;
    }

    private static TagKey<Item> repairTag(String mat) {
        return TagKey.of(RegistryKeys.ITEM, id("repairs_" + mat));
    }

    private static Map<EquipmentType, Integer> defense(int boots, int legs, int chest, int helm) {
        Map<EquipmentType, Integer> m = new EnumMap<>(EquipmentType.class);
        m.put(EquipmentType.BOOTS, boots);
        m.put(EquipmentType.LEGGINGS, legs);
        m.put(EquipmentType.CHESTPLATE, chest);
        m.put(EquipmentType.HELMET, helm);
        m.put(EquipmentType.BODY, chest);
        return m;
    }

    private static RegistryEntry<SoundEvent> equipSound(int i) {
        return switch (i) {
            case 0 -> SoundEvents.ITEM_ARMOR_EQUIP_IRON;
            case 1, 3 -> SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND;
            default -> SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE;
        };
    }

    private static ToolMaterial toolMat(int durability, float speed, int enchant, String repairMat) {
        return new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, durability, speed, 0.0f, enchant, repairTag(repairMat));
    }

    static {
        // --- руды, сырьё, слитки ---
        float[][] oreStats = {{3f, 3f}, {3f, 3f}, {3.5f, 4f}, {5f, 6f}, {6f, 9f}};
        for (int i = 0; i < 5; i++) {
            ORE[i] = block(MATS[i] + "_ore", oreStats[i][0], oreStats[i][1], BlockSoundGroup.STONE, true, Block::new);
            RAW[i] = item("raw_" + MATS[i], Item::new, null);
            INGOT[i] = item(MATS[i] + "_ingot", Item::new, null);
        }

        // --- броня ---
        int[][] def = {{2, 5, 6, 2}, {3, 6, 8, 3}, {3, 6, 8, 3}, {4, 7, 9, 4}, {5, 8, 10, 5}};
        int[] dur = {20, 33, 40, 50, 70};
        float[] tough = {0f, 2f, 3f, 4f, 6f};
        float[] kb = {0f, 0f, 0.1f, 0.1f, 0.2f};
        int[] ench = {12, 10, 15, 18, 25};
        String[] part = {"_helmet", "_chestplate", "_leggings", "_boots"};
        EquipmentType[] types = {EquipmentType.HELMET, EquipmentType.CHESTPLATE, EquipmentType.LEGGINGS, EquipmentType.BOOTS};
        Rarity[] rar = {Rarity.COMMON, Rarity.UNCOMMON, Rarity.RARE, Rarity.EPIC, Rarity.EPIC};

        for (int i = 0; i < 5; i++) {
            RegistryKey<EquipmentAsset> assetKey = RegistryKey.of(EquipmentAssetKeys.REGISTRY_KEY, id(MATS[i]));
            ArmorMaterial mat = new ArmorMaterial(dur[i], defense(def[i][0], def[i][1], def[i][2], def[i][3]),
                    ench[i], equipSound(i), tough[i], kb[i], repairTag(MATS[i]), assetKey);
            for (int p = 0; p < 4; p++) {
                final EquipmentType type = types[p];
                final Rarity r = rar[i];
                ARMOR[i][p] = item(MATS[i] + part[p], Item::new, s -> s.armor(mat, type).rarity(r));
            }
        }

        // --- топоры ---
        // итоговый урон = 1 (база) + параметр. Кратос 7, Зевс 11, Ад 15, Небеса 25.
        KRATOS_AXE = item("kratos_axe",
                s -> new AxeItem(toolMat(1800, 7f, 15, "rune"), 6f, -2.8f, s), s -> s.rarity(Rarity.UNCOMMON));
        ZEUS_AXE = item("zeus_axe",
                s -> new AxeItem(toolMat(2500, 8f, 15, "storm"), 10f, -2.8f, s), s -> s.rarity(Rarity.RARE));
        HELL_AXE = item("hell_axe",
                s -> new AxeItem(toolMat(3200, 9f, 15, "hellfire"), 14f, -2.8f, s), s -> s.rarity(Rarity.RARE));
        HEAVEN_AXE = item("heaven_axe",
                s -> new AxeItem(toolMat(5000, 11f, 20, "celestial"), 24f, -2.8f, s), s -> s.rarity(Rarity.EPIC));
        // атрибут урона в игре ограничен 2048, поэтому реальные 7777 наносит HavenMod (см. AttackEntityCallback)
        GALAXY_AXE = item("galaxy_axe",
                s -> new AxeItem(toolMat(32000, 20f, 30, "cosmic"), 2047f, -2.8f, s), s -> s.rarity(Rarity.EPIC));

        // --- лепидодендрон ---
        LEPIDODENDRON_LOG = block("lepidodendron_log", 2.0f, 2.0f, BlockSoundGroup.WOOD, false, PillarBlock::new);
        LEPIDODENDRON_LEAVES = block("lepidodendron_leaves", 0.3f, 0.3f, BlockSoundGroup.GRASS, false, Block::new);
    }

    public static void init() {}

    private ModContent() {}
}
