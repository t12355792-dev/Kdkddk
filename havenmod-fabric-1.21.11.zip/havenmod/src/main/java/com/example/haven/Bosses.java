package com.example.haven;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.VexEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Мини-боссы и боссы. Это обычные мобы Minecraft с усиленными характеристиками,
 * размером, именем и способностями, поэтому клиенту не нужны особые рендереры.
 */
public final class Bosses {
    private static final String TAG_PREFIX = "wt_boss_";
    private static final String TAG_ROLLED = "wt_rolled";

    record Drop(Item item, int min, int max) {}

    record Def(String id, String name, EntityType<? extends MobEntity> type, double hp, double dmg, double scale,
               BossBar.Color color, Item weapon, boolean mini, List<Drop> drops) {}

    static final class Tracked {
        final ServerWorld world; final MobEntity e; final Def d; final ServerBossBar bar;
        int age = 0; boolean dropped = false;
        Tracked(ServerWorld world, MobEntity e, Def d, ServerBossBar bar) { this.world = world; this.e = e; this.d = d; this.bar = bar; }
    }

    private static final Map<String, Def> DEFS = new LinkedHashMap<>();
    private static final Map<UUID, Tracked> TRACKED = new HashMap<>();

    private Bosses() {}

    public static Set<String> ids() { return DEFS.keySet(); }

    private static void def(String id, String name, EntityType<? extends MobEntity> type, double hp, double dmg, double scale,
                            BossBar.Color color, Item weapon, boolean mini, Drop... drops) {
        DEFS.put(id, new Def(id, name, type, hp, dmg, scale, color, weapon, mini, List.of(drops)));
    }

    public static void init() {
        Item[] I = ModContent.INGOT;
        // мини-боссы
        def("stone_brute", "Каменный громила", EntityType.ZOMBIE, 120, 10, 1.5, BossBar.Color.WHITE,
                ModContent.KRATOS_AXE, true, new Drop(I[0], 2, 4), new Drop(ModContent.RAW[0], 1, 3));
        def("bone_warden", "Костяной страж", EntityType.WITHER_SKELETON, 150, 12, 1.5, BossBar.Color.WHITE,
                ModContent.KRATOS_AXE, true, new Drop(I[1], 2, 4));
        def("ash_piglin", "Пепельный пиглин", EntityType.PIGLIN_BRUTE, 180, 14, 1.5, BossBar.Color.WHITE,
                ModContent.ZEUS_AXE, true, new Drop(I[2], 2, 4));
        // боссы
        def("thunder_lord", "Громовержец", EntityType.VINDICATOR, 600, 20, 2.5, BossBar.Color.YELLOW,
                ModContent.ZEUS_AXE, false, new Drop(I[1], 8, 12), new Drop(I[3], 1, 2));
        def("hell_lord", "Владыка Бездны", EntityType.WITHER_SKELETON, 800, 28, 2.8, BossBar.Color.RED,
                ModContent.HELL_AXE, false, new Drop(I[2], 8, 12), new Drop(I[3], 1, 2));
        def("cosmic_guardian", "Космический Страж", EntityType.RAVAGER, 1000, 40, 2.2, BossBar.Color.PURPLE,
                null, false, new Drop(I[4], 6, 10), new Drop(I[3], 3, 5));

        ServerTickEvents.END_WORLD_TICK.register(world -> {
            try {
                tick(world);
            } catch (Exception ex) {
                HavenMod.LOGGER.error("boss tick failed", ex);
            }
        });

        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!(entity instanceof MobEntity mob)) return;
            Set<String> tags = entity.getCommandTags();
            for (String tag : tags) {
                if (tag.startsWith(TAG_PREFIX)) {
                    Def d = DEFS.get(tag.substring(TAG_PREFIX.length()));
                    if (d != null && !TRACKED.containsKey(entity.getUuid())) track(world, mob, d);
                    return;
                }
            }
            // естественный спавн мини-боссов
            String id = null;
            int chance = 0;
            if (entity.getType() == EntityType.ZOMBIE) { id = "stone_brute"; chance = 150; }
            else if (entity.getType() == EntityType.WITHER_SKELETON) { id = "bone_warden"; chance = 15; }
            else if (entity.getType() == EntityType.PIGLIN_BRUTE) { id = "ash_piglin"; chance = 6; }
            if (id == null || tags.contains(TAG_ROLLED)) return;
            entity.addCommandTag(TAG_ROLLED);
            if (world.random.nextInt(chance) == 0) {
                Def d = DEFS.get(id);
                apply(mob, d);
                track(world, mob, d);
            }
        });

        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
            Tracked t = TRACKED.remove(entity.getUuid());
            if (t != null && t.bar != null) t.bar.clearPlayers();
        });
    }

    // ------------------------------------------------------------- создание

    private static void setAttr(MobEntity m, RegistryEntry<EntityAttribute> attr, double v) {
        EntityAttributeInstance inst = m.getAttributeInstance(attr);
        if (inst != null) inst.setBaseValue(v);
    }

    private static void apply(MobEntity m, Def d) {
        setAttr(m, EntityAttributes.MAX_HEALTH, d.hp());
        m.setHealth((float) d.hp());
        setAttr(m, EntityAttributes.ATTACK_DAMAGE, d.dmg());
        setAttr(m, EntityAttributes.SCALE, d.scale());
        setAttr(m, EntityAttributes.KNOCKBACK_RESISTANCE, d.mini() ? 0.5 : 1.0);
        setAttr(m, EntityAttributes.FOLLOW_RANGE, 48);
        m.setCustomName(Text.literal(d.name()).formatted(d.mini() ? Formatting.GOLD : Formatting.DARK_RED));
        m.setCustomNameVisible(true);
        m.setPersistent();
        m.addCommandTag(TAG_PREFIX + d.id());
        m.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, StatusEffectInstance.INFINITE, 0, false, false));
        if (d.weapon() != null) m.equipStack(EquipmentSlot.MAINHAND, new ItemStack(d.weapon()));
    }

    private static void track(ServerWorld w, MobEntity m, Def d) {
        ServerBossBar bar = null;
        if (!d.mini()) {
            bar = new ServerBossBar(Text.literal(d.name()), d.color(), BossBar.Style.NOTCHED_10);
        }
        TRACKED.put(m.getUuid(), new Tracked(w, m, d, bar));
    }

    public static boolean summon(ServerWorld w, String id, double x, double y, double z) {
        Def d = DEFS.get(id);
        if (d == null) return false;
        MobEntity m = d.type().create(w, SpawnReason.COMMAND);
        if (m == null) return false;
        m.refreshPositionAndAngles(x, y, z, 0f, 0f);
        apply(m, d);
        w.spawnEntity(m);
        track(w, m, d);
        return true;
    }

    // ------------------------------------------------------------------ тик

    private static void tick(ServerWorld world) {
        Iterator<Tracked> it = TRACKED.values().iterator();
        while (it.hasNext()) {
            Tracked t = it.next();
            if (t.world != world) continue;

            if (t.e.isDead()) {
                if (!t.dropped) { t.dropped = true; dropLoot(world, t); }
                if (t.bar != null) t.bar.clearPlayers();
                it.remove();
                continue;
            }
            if (t.e.isRemoved()) {
                if (t.bar != null) t.bar.clearPlayers();
                it.remove();
                continue;
            }

            t.age++;
            if (t.bar != null) {
                t.bar.setPercent(Math.max(0f, Math.min(1f, t.e.getHealth() / t.e.getMaxHealth())));
                Collection<ServerPlayerEntity> in = t.bar.getPlayers();
                for (ServerPlayerEntity p : world.getPlayers()) {
                    boolean near = p.squaredDistanceTo(t.e) < 64.0 * 64.0;
                    boolean has = in.contains(p);
                    if (near && !has) t.bar.addPlayer(p);
                    else if (!near && has) t.bar.removePlayer(p);
                }
            }
            abilities(world, t);
        }
    }

    private static List<ServerPlayerEntity> playersNear(ServerWorld w, MobEntity e, double r) {
        List<ServerPlayerEntity> out = new ArrayList<>();
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (!p.isSpectator() && p.squaredDistanceTo(e) <= r * r) out.add(p);
        }
        return out;
    }

    private static void abilities(ServerWorld w, Tracked t) {
        MobEntity e = t.e;
        LivingEntity target = e.getTarget();
        switch (t.d.id()) {
            case "stone_brute" -> {
                if (t.age % 100 == 0) {
                    for (ServerPlayerEntity p : playersNear(w, e, 5)) {
                        p.takeKnockback(1.2, e.getX() - p.getX(), e.getZ() - p.getZ());
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
                    }
                    w.spawnParticles(ParticleTypes.POOF, e.getX(), e.getY() + 0.3, e.getZ(), 40, 2.5, 0.2, 2.5, 0.05);
                }
            }
            case "bone_warden" -> {
                if (t.age % 120 == 0) {
                    for (ServerPlayerEntity p : playersNear(w, e, 6)) {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, 0));
                    }
                    w.spawnParticles(ParticleTypes.SMOKE, e.getX(), e.getY() + 1, e.getZ(), 40, 2.5, 1, 2.5, 0.02);
                }
            }
            case "ash_piglin" -> {
                if (t.age % 100 == 0) {
                    for (ServerPlayerEntity p : playersNear(w, e, 5)) p.setOnFireFor(5);
                    w.spawnParticles(ParticleTypes.FLAME, e.getX(), e.getY() + 0.5, e.getZ(), 40, 2, 0.5, 2, 0.03);
                }
            }
            case "thunder_lord" -> {
                if (t.age % 80 == 0 && target != null) {
                    LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(w, SpawnReason.TRIGGERED);
                    if (bolt != null) {
                        bolt.refreshPositionAndAngles(target.getX(), target.getY(), target.getZ(), 0f, 0f);
                        w.spawnEntity(bolt);
                    }
                }
            }
            case "hell_lord" -> {
                if (t.age % 100 == 0) {
                    for (ServerPlayerEntity p : playersNear(w, e, 8)) {
                        p.setOnFireFor(6);
                        p.damage(w, w.getDamageSources().inFire(), 6f);
                    }
                    w.spawnParticles(ParticleTypes.FLAME, e.getX(), e.getY() + 1, e.getZ(), 120, 4, 1.5, 4, 0.06);
                    w.spawnParticles(ParticleTypes.LARGE_SMOKE, e.getX(), e.getY() + 1, e.getZ(), 40, 4, 1.5, 4, 0.03);
                }
            }
            case "cosmic_guardian" -> {
                if (t.age % 160 == 0 && target != null) {
                    for (int i = 0; i < 2; i++) {
                        VexEntity v = EntityType.VEX.create(w, SpawnReason.MOB_SUMMONED);
                        if (v == null) continue;
                        v.refreshPositionAndAngles(e.getX() + (i == 0 ? 2 : -2), e.getY() + 2, e.getZ(), 0f, 0f);
                        v.setTarget(target);
                        w.spawnEntity(v);
                    }
                }
                if (t.age % 200 == 0) {
                    for (ServerPlayerEntity p : playersNear(w, e, 8)) {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 40, 1));
                    }
                    w.spawnParticles(ParticleTypes.END_ROD, e.getX(), e.getY() + 1, e.getZ(), 60, 3, 1.5, 3, 0.05);
                }
            }
            default -> {}
        }
    }

    private static void dropLoot(ServerWorld w, Tracked t) {
        for (Drop d : t.d.drops()) {
            int n = d.min() + (d.max() > d.min() ? w.random.nextInt(d.max() - d.min() + 1) : 0);
            if (n <= 0) continue;
            ItemEntity ie = new ItemEntity(w, t.e.getX(), t.e.getY() + 0.5, t.e.getZ(), new ItemStack(d.item(), n));
            w.spawnEntity(ie);
        }
    }
}
